/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

import {getNullTerminatedStringFromDataView, getStringFromDataView, pushMetadataBlock} from './utils.js';
// import {get64BitValue} from './image-header-iso-bmff-utils.js';
import {parseItemLocationBox} from './image-header-iso-bmff-iloc.js';
import {hasBytes} from './image-header-iso-bmff-utils.js';

// HEIC and AVIF files are based on the ISO-BMFF format. This file format is
// built up by boxes. There are boxes and full boxes. All box types have a
// length (4 or 8 bytes) and a type (4 bytes). Full boxes also have a version
// (1 byte) and flags (3 bytes). The boxes can be nested. Each box type has its
// own structure that can be seen in the specification.
//
// For metadata we are interested in the meta box. The meta box contains sub
// boxes. The sub box type iinf has info about which types of metadata are
// present in the file. The item ID we get from there we then look up in the
// iloc sub box to get the offset to the real location of the metadata.
//
// The ICC profiles is a bit more nested. We have to look in
// meta > iprp > ipco > colr, and then the whole profile is stored there.

// These are actually 32-bit strings, not random IDs, e.g. "ftyp" and "meta".
const TYPE_FTYP = 0x66747970;
const TYPE_IPRP = 0x69707270;
const TYPE_META = 0x6d657461;
const TYPE_ILOC = 0x696c6f63;
const TYPE_IDAT = 0x69646174;
const TYPE_IINF = 0x69696e66;
const TYPE_INFE = 0x696e6665;
const TYPE_IPCO = 0x6970636f;
const TYPE_COLR = 0x636f6c72;
const TYPE_PITM = 0x7069746d;
const TYPE_IPMA = 0x69706d61;
const TYPE_ISPE = 0x69737065;
const TYPE_PIXI = 0x70697869;

// const EXTENSION_TYPE_FDEL = 0x6664656c;

export const ITEM_INFO_TYPE_EXIF = 0x45786966;
export const ITEM_INFO_TYPE_MIME = 0x6d696d65;
const ITEM_INFO_TYPE_URI = 0x75726920;

// The spec sets no maximum for the infe strings; the cap bounds the memory one
// malformed string can take, far above any real name, MIME type or URI.
const MAX_INFE_STRING_LENGTH = 65536;

export const BOX_TYPE_OFFSET = 4;
export const BOX_MIN_LENGTH = 8;

const FULL_BOX_VERSION_AND_FLAGS_SIZE = 4;

// Every ipco child the parser does not know shares this entry, so an ipco
// packed with them costs one array slot per child, not one object.
const UNKNOWN_PROPERTY = {type: undefined};

/**
 * Parses a ISO-BMFF box from the provided data view starting at the given offset.
 *
 * @param {DataView} dataView - The DataView to parse.
 * @param {number} offset - The offset at which to start parsing.
 * @param {number} [containerEnd] - The end of the box that declares this one.
 *     A box may not read past it, whatever length it declares for itself.
 *     Defaults to the end of the data, which is what the outermost boxes get.
 * @returns {Object} The parsed box.
 */
export function parseBox(dataView, offset, containerEnd = dataView.byteLength) {
    const VERSION_SIZE = 1;

    if (!hasBytes(dataView, offset, BOX_MIN_LENGTH)) {
        return undefined;
    }

    // A malformed box can make a deeper read overrun the buffer; treat it as
    // unparseable (return undefined) rather than throw a RangeError to the caller.
    try {
        const {length, contentOffset} = getBoxLength(dataView, offset);
        // An extended-size box has a 16-byte header, not 8.
        if (length < contentOffset - offset || contentOffset > containerEnd) {
            return undefined;
        }

        const type = dataView.getUint32(offset + BOX_TYPE_OFFSET);

        if (type === TYPE_FTYP) {
            return parseFileTypeBox(dataView, contentOffset, length);
        }
        if (type === TYPE_IPRP) {
            return parseItemPropertiesBox(dataView, offset, contentOffset, length, containerEnd);
        }
        if (type === TYPE_IPCO) {
            return parseItemPropertyContainerBox(dataView, offset, contentOffset, length, containerEnd);
        }
        if (type === TYPE_COLR) {
            return parseColorInformationBox(dataView, contentOffset, length);
        }
        if (type === TYPE_IDAT) {
            // idat is a plain box (no version/flags); its data starts directly
            // after the box header.
            return parseItemDataBox(contentOffset, length);
        }

        // The following are full boxes, also containing version and flags.
        if (!hasBytes(dataView, contentOffset, VERSION_SIZE)) {
            return undefined;
        }
        const version = dataView.getUint8(contentOffset);

        if (type === TYPE_META) {
            return parseMetadataBox(dataView, offset, contentOffset + VERSION_SIZE, length, containerEnd);
        }
        if (type === TYPE_ILOC) {
            return parseItemLocationBox(dataView, offset, version, contentOffset + VERSION_SIZE, length, containerEnd);
        }
        if (type === TYPE_IINF) {
            return parseItemInformationBox(dataView, offset, version, contentOffset + VERSION_SIZE, length, containerEnd);
        }
        if (type === TYPE_INFE) {
            return parseItemInformationEntryBox(dataView, offset, version, contentOffset + VERSION_SIZE, length, containerEnd);
        }
        if (type === TYPE_PITM) {
            return parsePrimaryItemBox(dataView, offset, version, contentOffset, length, containerEnd);
        }
        if (type === TYPE_IPMA) {
            return parseItemPropertyAssociationBox(dataView, offset, version, contentOffset, length, containerEnd);
        }
        if (type === TYPE_ISPE) {
            return parseImageSpatialExtentsBox(dataView, offset, contentOffset, length, containerEnd);
        }
        if (type === TYPE_PIXI) {
            return parsePixelInformationBox(dataView, offset, version, contentOffset, length, containerEnd);
        }

        return getUnknownBox(length);
    } catch (error) {
        return undefined;
    }
}

/**
 * Checks if the data view starts with an ftyp box whose major brand is one
 * of the provided brands.
 *
 * @param {DataView} dataView The data view to check.
 * @param {Array<string>} brands The major brands to accept.
 * @returns {boolean} True if the file's major brand is in the list.
 */
export function hasMajorBrand(dataView, brands) {
    if (!dataView) {
        return false;
    }

    try {
        const headerBox = parseBox(dataView, 0);
        return headerBox !== undefined && brands.indexOf(headerBox.majorBrand) !== -1;
    } catch (error) {
        return false;
    }
}

/**
 * @typedef {Object} BoxLength
 * @property {number} length The length of the box including length and type.
 * @property {number} contentOffset
 */

/**
 * @param {DataView} dataView
 * @param {number} offset
 * @returns {BoxLength}
 */
export function getBoxLength(dataView, offset) {
    const BOX_LENGTH_SIZE = 4;
    const BOX_TYPE_SIZE = 4;
    const BOX_EXTENDED_SIZE = 8;
    const BOX_EXTENDED_SIZE_LOW_OFFSET = 12;
    const BOX_EXTENDED_FULL_SIZE = BOX_LENGTH_SIZE + BOX_TYPE_SIZE + BOX_EXTENDED_SIZE;

    const boxLength = dataView.getUint32(offset);
    if (extendsToEndOfFile(boxLength)) {
        return {
            length: dataView.byteLength - offset,
            contentOffset: offset + BOX_LENGTH_SIZE + BOX_TYPE_SIZE,
        };
    }
    if (hasExtendedSize(boxLength)) {
        if (!hasBytes(dataView, offset, BOX_EXTENDED_FULL_SIZE)) {
            // Extended size field absent; length 0 makes parseBox treat it as unparseable.
            return {length: 0, contentOffset: offset + BOX_LENGTH_SIZE + BOX_TYPE_SIZE};
        }
        if (hasEmptyHighBits(dataView, offset)) {
            // It's a bit tricky to handle 64 bit numbers in JavaScript. Let's
            // wait until there are real-world examples where it is necessary.
            return {
                length: dataView.getUint32(offset + BOX_EXTENDED_SIZE_LOW_OFFSET),
                contentOffset: offset + BOX_LENGTH_SIZE + BOX_TYPE_SIZE + BOX_EXTENDED_SIZE,
            };
        }
    }

    return {
        length: boxLength,
        contentOffset: offset + BOX_LENGTH_SIZE + BOX_TYPE_SIZE,
    };
}

function extendsToEndOfFile(boxLength) {
    return boxLength === 0;
}

function hasExtendedSize(boxLength) {
    return boxLength === 1;
}

function hasEmptyHighBits(dataView, offset) {
    const BOX_EXTENDED_SIZE_OFFSET = 8;
    return dataView.getUint32(offset + BOX_EXTENDED_SIZE_OFFSET) === 0;
}

/**
 * @typedef {Object} Offsets
 * @property {number} tiffHeaderOffset
 * @property {Array<Object>} xmpChunks
 * @property {Array<Object>} iccChunks
 * @property {boolean} hasAppMarkers
 * @property {DataView=} exifDataView Synthetic buffer when an Exif item
 *     spans multiple extents. tiffHeaderOffset then indexes into this view
 *     rather than the source dataView.
 * @property {DataView=} xmpDataView Synthetic buffer when an XMP item
 *     spans multiple extents. xmpChunks then references this view.
 * @property {number=} imageDimensionsOffset Offset of the primary item's
 *     dimensions, the width and height fields of its ispe property; absent
 *     when it cannot be resolved.
 * @property {number=} pixelInformationOffset Offset of the num_channels
 *     field of the primary item's pixi property; the per-channel bit depths
 *     follow it. Absent when it cannot be resolved.
 */

/**
 * Finds the offsets of ISO-BMFF-structured data in the provided data view.
 *
 * @param {DataView} dataView The data view to find offsets in.
 * @param {Array<Object>=} metadataBlocks Optional out-array. When provided,
 *     receives one block per iloc extent (Exif/XMP) at the resolved file
 *     offset (cm 0 direct, cm 1 via the idat box) plus the ICC profile
 *     bytes. cm 2 (item_offset) items are skipped.
 * @returns {Offsets} The TIFF header offset, XMP chunks, ICC chunks,
 *     whether any of those were found, and the primary image's dimensions
 *     and pixel information offsets.
 */
export function findOffsets(dataView, metadataBlocks) {
    const metaBox = findMetaBox(dataView);
    const offsets = findMetadataOffsets(dataView, metaBox, metadataBlocks);
    const {imageDimensionsOffset, pixelInformationOffset} = findPrimaryItemPropertyOffsets(dataView, metaBox);
    if (imageDimensionsOffset !== undefined) {
        offsets.imageDimensionsOffset = imageDimensionsOffset;
    }
    if (pixelInformationOffset !== undefined) {
        offsets.pixelInformationOffset = pixelInformationOffset;
    }
    return offsets;
}

function findMetaBox(dataView) {
    const BOX_LENGTH_SIZE = 4;
    const BOX_TYPE_SIZE = 4;

    let offset = 0;

    while (offset + BOX_LENGTH_SIZE + BOX_TYPE_SIZE <= dataView.byteLength) {
        const box = parseBox(dataView, offset);

        if (box === undefined) {
            break;
        }

        if (box.type === 'meta') {
            return box;
        }

        offset += box.length;
    }

    return undefined;
}

function findMetadataOffsets(dataView, metaBox, metadataBlocks) {
    const offsets = {};

    if (!metaBox) {
        return {hasAppMarkers: false};
    }

    warnIfUnsupportedFieldSize(metaBox);

    const exif = findExifOffset(dataView, metaBox, metadataBlocks);
    if (exif !== undefined) {
        offsets.tiffHeaderOffset = exif.tiffHeaderOffset;
        if (exif.dataView !== undefined) {
            offsets.exifDataView = exif.dataView;
        }
    }
    const xmp = findXmpChunks(dataView, metaBox, metadataBlocks);
    if (xmp !== undefined) {
        offsets.xmpChunks = xmp.chunks;
        if (xmp.dataView !== undefined) {
            offsets.xmpDataView = xmp.dataView;
        }
    }
    offsets.iccChunks = findIccChunks(metaBox, metadataBlocks);
    offsets.hasAppMarkers = (offsets.tiffHeaderOffset !== undefined) || (offsets.xmpChunks !== undefined) || (offsets.iccChunks !== undefined);
    return offsets;
}

function warnIfUnsupportedFieldSize(metaBox) {
    const ilocBox = metaBox.subBoxes.find((box) => box.type === 'iloc');
    if (ilocBox && ilocBox.uses64BitFields) {
        // eslint-disable-next-line no-console
        console.warn('This file uses 8-byte iloc offset, length or index fields which are currently not fully supported by ExifReader. Contact the maintainer to get it fixed.');
    }
}

function findExifOffset(dataView, metaBox, metadataBlocks) {
    try {
        const exifItemId = findIinfExifItemId(metaBox).itemId;
        const ilocItem = findIlocItem(metaBox, exifItemId);
        warnIfUnsupportedConstructionMethod(ilocItem);
        const idatContentOffset = findIdatContentOffset(metaBox);
        pushIlocExtentBlocks(metadataBlocks, ilocItem, 'exif', idatContentOffset);
        if (ilocItem.extents.length > 1) {
            const assembled = assembleExtents(dataView, ilocItem, idatContentOffset);
            if (assembled === undefined) {
                return undefined;
            }
            return {
                tiffHeaderOffset: getTiffHeaderOffset(assembled, 0),
                dataView: assembled,
            };
        }
        const exifOffset = resolveExtentToFileOffset(ilocItem, ilocItem.extents[0], idatContentOffset);
        if (exifOffset === undefined) {
            return undefined;
        }
        return {tiffHeaderOffset: getTiffHeaderOffset(dataView, exifOffset)};
    } catch (error) {
        return undefined;
    }
}

function pushIlocExtentBlocks(metadataBlocks, ilocItem, blockType, idatContentOffset) {
    if (!metadataBlocks) {
        return;
    }
    for (let i = 0; i < ilocItem.extents.length; i++) {
        const extent = ilocItem.extents[i];
        const start = resolveExtentToFileOffset(ilocItem, extent, idatContentOffset);
        if (start === undefined) {
            continue;
        }
        pushMetadataBlock(metadataBlocks, blockType, start, start + extent.extentLength);
    }
}

// Translates an iloc extent to a real file offset.
// cm 0 / undefined: baseOffset + extentOffset is already a file offset.
// cm 1 (idat): bytes live inside the meta box's idat sub-box.
// cm 2 (item): not yet supported; returns undefined so the item is skipped.
function resolveExtentToFileOffset(ilocItem, extent, idatContentOffset) {
    const cm = ilocItem.constructionMethod;
    if (cm === undefined || cm === 0) {
        return ilocItem.baseOffset + extent.extentOffset;
    }
    if (cm === 1 && idatContentOffset !== undefined) {
        return idatContentOffset + ilocItem.baseOffset + extent.extentOffset;
    }
    return undefined;
}

function findIdatContentOffset(metaBox) {
    const idatBox = metaBox.subBoxes.find((box) => box.type === 'idat');
    return idatBox ? idatBox.contentOffset : undefined;
}

function warnIfUnsupportedConstructionMethod(ilocItem) {
    if (ilocItem.constructionMethod === 2) {
        // eslint-disable-next-line no-console
        console.warn('This file uses iloc constructionMethod 2 (item_offset) which is currently not supported by ExifReader. Contact the maintainer to get it fixed.');
    }
}

// Copies the bytes of every iloc extent into a single contiguous buffer.
// Used when an item spans more than one extent, the parsers downstream
// require contiguous bytes. Returns undefined if any extent fails to
// resolve or falls outside the source dataView.
function assembleExtents(dataView, ilocItem, idatContentOffset) {
    const resolved = [];
    let totalLength = 0;
    for (let i = 0; i < ilocItem.extents.length; i++) {
        const extent = ilocItem.extents[i];
        const start = resolveExtentToFileOffset(ilocItem, extent, idatContentOffset);
        if (start === undefined || start + extent.extentLength > dataView.byteLength) {
            return undefined;
        }
        resolved.push({start, length: extent.extentLength});
        totalLength += extent.extentLength;
        // A reassembled item can never legitimately be larger than the source
        // file. Overlapping extents could otherwise amplify the allocation.
        if (totalLength > dataView.byteLength) {
            return undefined;
        }
    }
    const buffer = new Uint8Array(totalLength);
    let writeOffset = 0;
    for (let i = 0; i < resolved.length; i++) {
        const {start, length} = resolved[i];
        for (let j = 0; j < length; j++) {
            buffer[writeOffset + j] = dataView.getUint8(start + j);
        }
        writeOffset += length;
    }
    return new DataView(buffer.buffer);
}

function findIinfExifItemId(metaBox) {
    return metaBox.subBoxes.find((box) => box.type === 'iinf').itemInfos.find((itemInfo) => itemInfo.itemType === ITEM_INFO_TYPE_EXIF);
}

function findIlocItem(metaBox, itemId) {
    return metaBox.subBoxes.find((box) => box.type === 'iloc').items.find((item) => item.itemId === itemId);
}

export function getTiffHeaderOffset(dataView, exifOffset) {
    // ISO-BMFF formatted files store the Exif data as an "Exif block" where the
    // first 32 bits is the TIFF header offset.
    const TIFF_HEADER_OFFSET_SIZE = 4;
    return exifOffset + TIFF_HEADER_OFFSET_SIZE + dataView.getUint32(exifOffset);
}

function findXmpChunks(dataView, metaBox, metadataBlocks) {
    try {
        const xmpItemId = findIinfXmpItemId(metaBox).itemId;
        const ilocItem = findIlocItem(metaBox, xmpItemId);
        warnIfUnsupportedConstructionMethod(ilocItem);
        const idatContentOffset = findIdatContentOffset(metaBox);
        pushIlocExtentBlocks(metadataBlocks, ilocItem, 'xmp', idatContentOffset);
        if (ilocItem.extents.length > 1) {
            const assembled = assembleExtents(dataView, ilocItem, idatContentOffset);
            if (assembled === undefined) {
                return undefined;
            }
            return {
                chunks: [{dataOffset: 0, length: assembled.byteLength}],
                dataView: assembled,
            };
        }
        const ilocItemExtent = ilocItem.extents[0];
        const dataOffset = resolveExtentToFileOffset(ilocItem, ilocItemExtent, idatContentOffset);
        if (dataOffset === undefined) {
            return undefined;
        }
        return {
            chunks: [
                {
                    dataOffset,
                    length: ilocItemExtent.extentLength,
                }
            ],
        };
    } catch (error) {
        return undefined;
    }
}

function findIinfXmpItemId(metaBox) {
    return metaBox.subBoxes.find((box) => box.type === 'iinf')
        .itemInfos.find((itemInfo) => itemInfo.itemType === ITEM_INFO_TYPE_MIME && itemInfo.contentType === 'application/rdf+xml');
}

function findIccChunks(metaBox, metadataBlocks) {
    // This finds the first ICC chunk, but there could be one for each image
    // that is embedded in the file. If it turns out we need to match the ICC
    // chunk to a specific image, we need to check the "ipma" in addition to the
    // "ipco", as findItemAssociations does for the primary item's ispe.
    try {
        const icc = metaBox.subBoxes.find((box) => box.type === 'iprp')
            .subBoxes.find((box) => box.type === 'ipco')
            .properties.find((box) => box.type === 'colr')
            .icc;
        if (icc) {
            pushMetadataBlock(metadataBlocks, 'icc', icc.offset, icc.offset + icc.length);
            return [icc];
        }
    } catch (error) {
        // Let it pass through.
    }
    return undefined;
}

// Resolves meta > pitm (the primary item) through meta > iprp > ipma (its
// property indexes) to the ispe and pixi among meta > iprp > ipco's children.
function findPrimaryItemPropertyOffsets(dataView, metaBox) {
    // Every read below is bounded at parse time; the catch keeps a malformed
    // box from failing the whole file when that bounding is ever wrong.
    try {
        if (!metaBox) {
            return {};
        }
        const pitm = metaBox.subBoxes.find((box) => box.type === 'pitm');
        const iprp = metaBox.subBoxes.find((box) => box.type === 'iprp');
        if (!pitm || !iprp) {
            return {};
        }
        const ipco = iprp.subBoxes.find((box) => box.type === 'ipco');
        if (!ipco) {
            return {};
        }
        const propertyIndexes = findItemPropertyIndexes(dataView, iprp.subBoxes, pitm.itemId);
        if (!propertyIndexes) {
            return {};
        }
        const ispe = findProperty(propertyIndexes, ipco.properties, 'ispe');
        const pixi = findProperty(propertyIndexes, ipco.properties, 'pixi');
        return {
            imageDimensionsOffset: ispe && ispe.dimensionsOffset,
            pixelInformationOffset: pixi && pixi.channelCountOffset,
        };
    } catch (error) {
        return {};
    }
}

function findItemPropertyIndexes(dataView, iprpSubBoxes, itemId) {
    for (let i = 0; i < iprpSubBoxes.length; i++) {
        if (iprpSubBoxes[i].type === 'ipma') {
            const propertyIndexes = findItemPropertyIndexesInIpma(dataView, iprpSubBoxes[i], itemId);
            if (propertyIndexes) {
                return propertyIndexes;
            }
        }
    }
    return undefined;
}

// The scan is bounded by the box's bytes, not by the counts it declares.
function findItemPropertyIndexesInIpma(dataView, ipma, itemId) {
    const ENTRY_COUNT_SIZE = 4;
    const ASSOCIATION_COUNT_SIZE = 1;
    const itemIdSize = ipma.version === 0 ? 2 : 4;
    const associationSize = (ipma.flags & 1) === 1 ? 2 : 1;

    const entryCount = dataView.getUint32(ipma.entryCountOffset);
    let offset = ipma.entryCountOffset + ENTRY_COUNT_SIZE;
    for (let i = 0; i < entryCount && offset + itemIdSize + ASSOCIATION_COUNT_SIZE <= ipma.end; i++) {
        const entryItemId = itemIdSize === 2 ? dataView.getUint16(offset) : dataView.getUint32(offset);
        const count = dataView.getUint8(offset + itemIdSize);
        offset += itemIdSize + ASSOCIATION_COUNT_SIZE;
        if (entryItemId === itemId) {
            const countWithinBox = Math.min(count, Math.floor((ipma.end - offset) / associationSize));
            return readPropertyIndexes(dataView, offset, countWithinBox, associationSize);
        }
        offset += count * associationSize;
    }
    return undefined;
}

function readPropertyIndexes(dataView, offset, count, associationSize) {
    // The top bit marks the property as essential; the rest is the 1-based index, 0 meaning no property.
    const indexMask = associationSize === 2 ? 0x7fff : 0x7f;
    const propertyIndexes = [];
    for (let i = 0; i < count; i++) {
        const associationOffset = offset + i * associationSize;
        const association = associationSize === 2 ? dataView.getUint16(associationOffset) : dataView.getUint8(associationOffset);
        propertyIndexes.push(association & indexMask);
    }
    return propertyIndexes;
}

function findProperty(propertyIndexes, properties, type) {
    for (let i = 0; i < propertyIndexes.length; i++) {
        const property = properties[propertyIndexes[i] - 1];
        if (property !== undefined && property.type === type) {
            return property;
        }
    }
    return undefined;
}

function parseFileTypeBox(dataView, contentOffset, boxLength) {
    const MAJOR_BRAND_SIZE = 4;
    const majorBrand = getStringFromDataView(dataView, contentOffset, MAJOR_BRAND_SIZE);

    return {
        type: 'ftyp',
        majorBrand,
        length: boxLength
    };
}

function parseItemPropertiesBox(dataView, startOffset, contentOffset, length, containerEnd) {
    return {
        type: 'iprp',
        subBoxes: parseSubBoxes(dataView, contentOffset, length - (contentOffset - startOffset), containerEnd),
        length,
    };
}

function parseItemPropertyContainerBox(dataView, startOffset, contentOffset, length, containerEnd) {
    return {
        type: 'ipco',
        properties: parseProperties(dataView, contentOffset, length - (contentOffset - startOffset), containerEnd),
        length,
    };
}

// ipma refers to a property by its 1-based position among all ipco children,
// so every child keeps its slot, known or not.
function parseProperties(dataView, offset, length, containerEnd) {
    const properties = [];
    walkSubBoxes(dataView, offset, length, containerEnd, (box) => {
        properties.push(box.type !== undefined ? box : UNKNOWN_PROPERTY);
    });
    return properties;
}

function parseColorInformationBox(dataView, contentOffset, length) {
    return {
        type: 'colr',
        icc: parseIcc(dataView, contentOffset),
        length,
    };
}

function parseIcc(dataView, contentOffset) {
    const COLOR_TYPE_SIZE = 4;

    const colorType = getStringFromDataView(dataView, contentOffset, COLOR_TYPE_SIZE);
    if (colorType !== 'prof' && colorType !== 'rICC') {
        // Support for nclx would require some restructuring for ICC handling.
        // Probably do it as a separate feature instead of combining with ICC.
        // Exiftool groups it under QuickTime. The test file test.avif has nclx.
        return undefined;
    }

    return {
        offset: contentOffset + COLOR_TYPE_SIZE,
        length: dataView.getUint32(contentOffset + COLOR_TYPE_SIZE),
        chunkNumber: 1,
        chunksTotal: 1
    };
}

function parseMetadataBox(dataView, startOffset, contentOffset, length, containerEnd) {
    const FLAGS_SIZE = 3;

    return {
        type: 'meta',
        subBoxes: parseSubBoxes(dataView, contentOffset + FLAGS_SIZE, length - (contentOffset + FLAGS_SIZE - startOffset), containerEnd),
        length
    };
}

function parseItemDataBox(contentOffset, length) {
    return {
        type: 'idat',
        contentOffset,
        length,
    };
}

function parsePrimaryItemBox(dataView, startOffset, version, contentOffset, length, containerEnd) {
    const itemIdOffset = contentOffset + FULL_BOX_VERSION_AND_FLAGS_SIZE;
    const itemIdSize = version === 0 ? 2 : 4;
    if (itemIdOffset + itemIdSize > getBoxEnd(dataView, startOffset, length, containerEnd)) {
        return getUnknownBox(length);
    }

    return {
        type: 'pitm',
        itemId: version === 0 ? dataView.getUint16(itemIdOffset) : dataView.getUint32(itemIdOffset),
        length
    };
}

// Only the header is read here; the entries are scanned once the primary item
// is known, so nothing is built per entry.
function parseItemPropertyAssociationBox(dataView, startOffset, version, contentOffset, length, containerEnd) {
    const ENTRY_COUNT_SIZE = 4;
    const FLAGS_MASK = 0xffffff;
    const entryCountOffset = contentOffset + FULL_BOX_VERSION_AND_FLAGS_SIZE;
    const end = getBoxEnd(dataView, startOffset, length, containerEnd);
    if (entryCountOffset + ENTRY_COUNT_SIZE > end) {
        return getUnknownBox(length);
    }

    return {
        type: 'ipma',
        version,
        flags: dataView.getUint32(contentOffset) & FLAGS_MASK,
        entryCountOffset,
        end,
        length
    };
}

function parseImageSpatialExtentsBox(dataView, startOffset, contentOffset, length, containerEnd) {
    const DIMENSIONS_SIZE = 8;
    const dimensionsOffset = contentOffset + FULL_BOX_VERSION_AND_FLAGS_SIZE;
    if (dimensionsOffset + DIMENSIONS_SIZE > getBoxEnd(dataView, startOffset, length, containerEnd)) {
        return getUnknownBox(length);
    }

    return {
        type: 'ispe',
        dimensionsOffset,
        length
    };
}

function parsePixelInformationBox(dataView, startOffset, version, contentOffset, length, containerEnd) {
    const CHANNEL_COUNT_SIZE = 1;
    const channelCountOffset = contentOffset + FULL_BOX_VERSION_AND_FLAGS_SIZE;
    const end = getBoxEnd(dataView, startOffset, length, containerEnd);
    if (version !== 0 || channelCountOffset + CHANNEL_COUNT_SIZE > end) {
        return getUnknownBox(length);
    }
    const channelCount = dataView.getUint8(channelCountOffset);
    if (channelCountOffset + CHANNEL_COUNT_SIZE + channelCount > end) {
        return getUnknownBox(length);
    }

    return {
        type: 'pixi',
        channelCountOffset,
        length
    };
}

function getBoxEnd(dataView, startOffset, length, containerEnd) {
    return Math.min(startOffset + length, containerEnd, dataView.byteLength);
}

function getUnknownBox(length) {
    return {
        type: undefined,
        length
    };
}

/**
 * @param {DataView} dataView
 * @param {number} offset The offset to start parsing from.
 * @param {number} length The length of all sub boxes combined.
 * @param {number} containerEnd The end of the box these sub boxes belong to.
 * @return {Array<Object>}
 */
function parseSubBoxes(dataView, offset, length, containerEnd) {
    const ACCEPTED_ITEM_INFO_TYPES = [
        ITEM_INFO_TYPE_EXIF,
        ITEM_INFO_TYPE_MIME,
    ];

    const subBoxes = [];
    walkSubBoxes(dataView, offset, length, containerEnd, (box) => {
        if (box.type !== undefined && (box.itemType === undefined || ACCEPTED_ITEM_INFO_TYPES.indexOf(box.itemType) !== -1)) {
            subBoxes.push(box);
        }
    });
    return subBoxes;
}

function walkSubBoxes(dataView, offset, length, containerEnd, onBox) {
    // A sub box may declare any length it likes, so bound it by the bytes this
    // container has, and by the ones that are really there when the file is
    // truncated. An overrunning box still gets parsed for what fits, which is
    // what keeps a cut-off file returning the metadata it does contain.
    const subBoxesEnd = Math.min(offset + length, containerEnd);

    let currentOffset = offset;
    // Requiring room for a whole header keeps a box from taking its type from
    // the bytes after the container, which invents one out of two boxes.
    while (currentOffset + BOX_MIN_LENGTH <= subBoxesEnd) {
        const box = parseBox(dataView, currentOffset, subBoxesEnd);
        if (box === undefined) {
            break;
        }
        onBox(box);
        currentOffset += box.length;
    }
}

function parseItemInformationBox(dataView, startOffset, version, contentOffset, length, containerEnd) {
    const FLAGS_SIZE = 3;
    const entryCountSize = version === 0 ? 2 : 4;
    const itemInfosOffset = contentOffset + FLAGS_SIZE + entryCountSize;

    return {
        type: 'iinf',
        itemInfos: parseSubBoxes(dataView, itemInfosOffset, length - (itemInfosOffset - startOffset), containerEnd),
        length
    };
}

function parseItemInformationEntryBox(dataView, startOffset, version, contentOffset, length, containerEnd) {
    const FLAGS_SIZE = 3;

    contentOffset += FLAGS_SIZE;
    const entry = {type: 'infe', length};
    const entryEnd = Math.min(startOffset + length, containerEnd);

    if (version === 0 || version === 1) {
        entry.itemId = dataView.getUint16(contentOffset);
        contentOffset += 2;
        entry.itemProtectionIndex = dataView.getUint16(contentOffset);
        contentOffset += 2;
        entry.itemName = readEntryString(dataView, contentOffset, entryEnd).value;
        contentOffset += entry.itemName.length + 1;
        // entry.contentType = getNullTerminatedStringFromDataView(dataView, offset);
        // offset += entry.contentType.length + 1;
        // Since contentEncoding is optional we need to check the offset against length here.
        // entry.contentEncoding = getNullTerminatedStringFromDataView(dataView, offset);
        // offset += entry.contentEncoding.length + 1;
    }
    // The following code should be correct but we currently don't need it.
    // if (version === 1) {
    //     // Everything here is optional, check the offset against length.
    //     entry.extensionType = dataView.getUint32(contentOffset);
    //     contentOffset += 4;
    //     if (entry.extensionType === EXTENSION_TYPE_FDEL) {
    //         entry.contentLocation = getNullTerminatedStringFromDataView(dataView, contentOffset);
    //         contentOffset += entry.contentLocation.length + 1;
    //         entry.contentMd5 = getNullTerminatedStringFromDataView(dataView, contentOffset);
    //         contentOffset += entry.contentMd5.length + 1;
    //         entry.contentLength = get64BitValue(dataView, contentOffset);
    //         contentOffset += 8;
    //         entry.transferLength = get64BitValue(dataView, contentOffset);
    //         contentOffset += 8;
    //         entry.entryCount = dataView.getUint8(contentOffset);
    //         contentOffset += 1;
    //         entry.entries = [];
    //         for (let i = 0; i < entry.entryCount; i++) {
    //             entry.entries.push({groupId: dataView.getUint32(contentOffset)});
    //             contentOffset += 4;
    //         }
    //     }
    // }
    if (version >= 2) {
        if (version === 2) {
            entry.itemId = dataView.getUint16(contentOffset);
            contentOffset += 2;
        } else if (version === 3) {
            entry.itemId = dataView.getUint32(contentOffset);
            contentOffset += 4;
        }
        entry.itemProtectionIndex = dataView.getUint16(contentOffset);
        contentOffset += 2;
        entry.itemType = dataView.getUint32(contentOffset);
        contentOffset += 4;
        const itemName = readEntryString(dataView, contentOffset, entryEnd);
        entry.itemName = itemName.value;
        if (!itemName.isTerminated) {
            return entry;
        }
        contentOffset += entry.itemName.length + 1;
        if (entry.itemType === ITEM_INFO_TYPE_MIME) {
            const contentType = readEntryString(dataView, contentOffset, entryEnd);
            entry.contentType = contentType.value;
            if (!contentType.isTerminated) {
                return entry;
            }
            contentOffset += entry.contentType.length + 1;
            if (entryEnd > contentOffset) {
                entry.contentEncoding = readEntryString(dataView, contentOffset, entryEnd).value;
            }
        } else if (entry.itemType === ITEM_INFO_TYPE_URI) {
            entry.itemUri = readEntryString(dataView, contentOffset, entryEnd).value;
        }
    }
    return entry;
}

/**
 * Reads one string of an infe box, bounded by the box end and the length cap.
 * isTerminated is false when the string ran into either bound instead of a NUL.
 */
function readEntryString(dataView, offset, entryEnd) {
    const limit = Math.min(entryEnd, offset + MAX_INFE_STRING_LENGTH);
    const value = getNullTerminatedStringFromDataView(dataView, offset, limit);
    return {value, isTerminated: offset + value.length < limit};
}
