/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

import {getStringFromDataView, pushMetadataBlock} from './utils.js';
import ByteOrder from './byte-order.js';
import {
    IFD_ENTRY_COUNT_LENGTH,
    IFD_ENTRY_LENGTH,
    NEXT_IFD_POINTER_LENGTH,
    TIFF_BYTE_ORDER_OFFSET,
    TIFF_HEADER_LENGTH,
    TIFF_ID,
    TIFF_ID_OFFSET,
    TIFF_IFD_OFFSET_OFFSET,
} from './tiff-constants.js';

export default {
    isJpegFile,
    findJpegOffsets
};

const MIN_JPEG_DATA_BUFFER_LENGTH = 2;
const JPEG_ID = 0xffd8;
const JPEG_ID_SIZE = 2;
const APP_ID_OFFSET = 4;
const APP_MARKER_SIZE = 2;
const JFIF_DATA_OFFSET = 2; // From start of APP0 marker.
const TIFF_HEADER_OFFSET = 10; // From start of APP1 marker.
const IPTC_DATA_OFFSET = 18; // From start of APP13 marker.
const XMP_DATA_OFFSET = 33; // From start of APP1 marker.
const XMP_EXTENDED_DATA_OFFSET = 79; // From start of APP1 marker including GUID, total length, and offset.
const APP2_ICC_DATA_OFFSET = 18; // From start of APP2 marker including marker and chunk/chunk total numbers.
const MPF_DATA_OFFSET = 8;

const APP2_ICC_IDENTIFIER = 'ICC_PROFILE\0';
const ICC_CHUNK_NUMBER_OFFSET = APP_ID_OFFSET + APP2_ICC_IDENTIFIER.length;
const ICC_TOTAL_CHUNKS_OFFSET = ICC_CHUNK_NUMBER_OFFSET + 1;
// Guards against memory exhaustion from a crafted file. Both chunk fields are a
// single byte, so a longer list could never be assembled into a profile anyway.
const MAX_ICC_CHUNKS = 255;
// Guards against memory exhaustion from a crafted file. An extended XMP segment
// holds at most about 64 KiB, so this still allows about 64 MiB of XMP.
const MAX_XMP_CHUNKS = 1024;

const APP2_MPF_IDENTIFIER = 'MPF\0';

const SOF0_MARKER = 0xffc0;
const SOF2_MARKER = 0xffc2;
const DHT_MARKER = 0xffc4;
const DQT_MARKER = 0xffdb;
const DRI_MARKER = 0xffdd;
const SOS_MARKER = 0xffda;

const APP0_MARKER = 0xffe0;
const APP1_MARKER = 0xffe1;
const APP2_MARKER = 0xffe2;
const APP13_MARKER = 0xffed;
const APP15_MARKER = 0xffef;
const COMMENT_MARKER = 0xfffe;

// Any number of fill bytes can be placed before an app marker. It's actually the first 0xff that is the
// fill byte and the next 0xff is either another fill byte or the first half of the next app marker.
const FILL_BYTE = 0xffff;

const APP0_JFIF_IDENTIFIER = 'JFIF';
const APP1_EXIF_IDENTIFIER = 'Exif';
const APP1_XMP_IDENTIFIER = 'http://ns.adobe.com/xap/1.0/\x00';
const APP1_XMP_EXTENDED_IDENTIFIER = 'http://ns.adobe.com/xmp/extension/\x00';
const APP13_IPTC_IDENTIFIER = 'Photoshop 3.0';
const APP13_RESOURCE_BLOCK_IDENTIFIER = '8BIM';

/**
 * Checks if the provided data view represents a JPEG file.
 *
 * @param {DataView} dataView The data view to check.
 * @returns {boolean} True if the data view starts with the JPEG SOI marker.
 */
function isJpegFile(dataView) {
    return !!dataView && (dataView.byteLength >= MIN_JPEG_DATA_BUFFER_LENGTH) && (dataView.getUint16(0) === JPEG_ID);
}

/**
 * Walks the JPEG APP/SOF markers and reports the offsets ExifReader needs.
 *
 * @param {DataView} dataView The data view to find offsets in.
 * @param {Array<Object>=} metadataBlocks Optional out-array. When provided,
 *     receives one block per recognized segment (Exif/XMP/IPTC/ICC/MPF/JFIF
 *     and SOF for file tags) and gets `truncated` set to true if the loop
 *     never saw the SOS marker.
 * @returns {Object} Per-segment offsets plus `hasAppMarkers`.
 */
function findJpegOffsets(dataView, metadataBlocks) {
    let appMarkerPosition = JPEG_ID_SIZE;
    let fieldLength;
    let sof0DataOffset;
    let sof2DataOffset;
    let jfifDataOffset;
    let tiffHeaderOffset;
    let iptcDataOffset;
    let xmpChunks;
    let iccChunks;
    let mpfDataOffset;
    let exifSegmentCount = 0;
    let bestExifSegment;
    let sawSos = false;

    while (appMarkerPosition + APP_ID_OFFSET + 5 <= dataView.byteLength) {
        let blockType;
        if (dataView.getUint16(appMarkerPosition) === SOS_MARKER) {
            // Reaching SOS means the metadata region is closed.
            sawSos = true;
        }
        if (isSOF0Marker(dataView, appMarkerPosition)) {
            fieldLength = dataView.getUint16(appMarkerPosition + APP_MARKER_SIZE);
            sof0DataOffset = appMarkerPosition + APP_MARKER_SIZE;
            blockType = 'file';
        } else if (isSOF2Marker(dataView, appMarkerPosition)) {
            fieldLength = dataView.getUint16(appMarkerPosition + APP_MARKER_SIZE);
            sof2DataOffset = appMarkerPosition + APP_MARKER_SIZE;
            blockType = 'file';
        } else if (isApp0JfifMarker(dataView, appMarkerPosition)) {
            fieldLength = dataView.getUint16(appMarkerPosition + APP_MARKER_SIZE);
            jfifDataOffset = appMarkerPosition + JFIF_DATA_OFFSET;
            blockType = 'jfif';
        } else if (isApp1ExifMarker(dataView, appMarkerPosition)) {
            fieldLength = dataView.getUint16(appMarkerPosition + APP_MARKER_SIZE);
            exifSegmentCount++;

            const currentTiffHeaderOffset = appMarkerPosition + TIFF_HEADER_OFFSET;

            if (exifSegmentCount === 1) {
                // The single-segment case must stay cheap, so the first
                // segment is only scored once a second one shows up.
                bestExifSegment = {
                    appMarkerPosition,
                    fieldLength,
                    tiffHeaderOffset: currentTiffHeaderOffset,
                    score: undefined,
                };
            } else {
                if (bestExifSegment.score === undefined) {
                    bestExifSegment.score = getExifMarkerScore(
                        dataView,
                        bestExifSegment.appMarkerPosition,
                        bestExifSegment.fieldLength,
                        bestExifSegment.tiffHeaderOffset
                    );
                }
                const currentExifSegmentScore = getExifMarkerScore(
                    dataView,
                    appMarkerPosition,
                    fieldLength,
                    currentTiffHeaderOffset
                );
                if (currentExifSegmentScore > bestExifSegment.score) {
                    bestExifSegment = {
                        appMarkerPosition,
                        fieldLength,
                        tiffHeaderOffset: currentTiffHeaderOffset,
                        score: currentExifSegmentScore,
                    };
                }
            }

            tiffHeaderOffset = bestExifSegment.tiffHeaderOffset;
            blockType = 'exif';
        } else if (isApp1XmpMarker(dataView, appMarkerPosition)) {
            if (!xmpChunks) {
                xmpChunks = [];
            }
            fieldLength = dataView.getUint16(appMarkerPosition + APP_MARKER_SIZE);
            if (xmpChunks.length < MAX_XMP_CHUNKS) {
                xmpChunks.push(getXmpChunkDetails(appMarkerPosition, fieldLength));
            }
            blockType = 'xmp';
        } else if (isApp1ExtendedXmpMarker(dataView, appMarkerPosition)) {
            if (!xmpChunks) {
                xmpChunks = [];
            }
            fieldLength = dataView.getUint16(appMarkerPosition + APP_MARKER_SIZE);
            if (xmpChunks.length < MAX_XMP_CHUNKS) {
                xmpChunks.push(getExtendedXmpChunkDetails(appMarkerPosition, fieldLength));
            }
            blockType = 'xmp';
        } else if (isApp13PhotoshopMarker(dataView, appMarkerPosition)) {
            fieldLength = dataView.getUint16(appMarkerPosition + APP_MARKER_SIZE);
            iptcDataOffset = appMarkerPosition + IPTC_DATA_OFFSET;
            blockType = 'iptc';
        } else if (isApp2ICCMarker(dataView, appMarkerPosition)) {
            fieldLength = dataView.getUint16(appMarkerPosition + APP_MARKER_SIZE);
            if (!iccChunks) {
                iccChunks = [];
            }
            if (iccChunks.length < MAX_ICC_CHUNKS) {
                const iccDataOffset = appMarkerPosition + APP2_ICC_DATA_OFFSET;
                const iccDataLength = fieldLength - (APP2_ICC_DATA_OFFSET - APP_MARKER_SIZE);

                const iccChunkNumber = dataView.getUint8(appMarkerPosition + ICC_CHUNK_NUMBER_OFFSET);
                const iccChunksTotal = dataView.getUint8(appMarkerPosition + ICC_TOTAL_CHUNKS_OFFSET);
                iccChunks.push({offset: iccDataOffset, length: iccDataLength, chunkNumber: iccChunkNumber, chunksTotal: iccChunksTotal});
            }
            blockType = 'icc';
        } else if (isApp2MPFMarker(dataView, appMarkerPosition)) {
            fieldLength = dataView.getUint16(appMarkerPosition + APP_MARKER_SIZE);
            mpfDataOffset = appMarkerPosition + MPF_DATA_OFFSET;
            blockType = 'mpf';
        } else if (isAppMarker(dataView, appMarkerPosition)) {
            fieldLength = dataView.getUint16(appMarkerPosition + APP_MARKER_SIZE);
        } else if (isFillByte(dataView, appMarkerPosition)) {
            appMarkerPosition++;
            continue;
        } else {
            break;
        }
        pushMetadataBlock(metadataBlocks, blockType, appMarkerPosition, appMarkerPosition + APP_MARKER_SIZE + fieldLength);
        appMarkerPosition += APP_MARKER_SIZE + fieldLength;
    }

    if (exifSegmentCount > 1) {
        warnAboutMultipleExifSegments(exifSegmentCount);
    }

    if (metadataBlocks) {
        // The while-condition requires +5 bytes to enter, so the SOS marker
        // can sit right at the boundary where the loop exits without
        // entering. Catch that here.
        if (!sawSos
            && appMarkerPosition + APP_MARKER_SIZE <= dataView.byteLength
            && dataView.getUint16(appMarkerPosition) === SOS_MARKER) {
            sawSos = true;
        }
        // The pipeline combines this with the per-block end <= byteLength
        // check to compute the overall `complete` flag.
        metadataBlocks.truncated = !sawSos;
    }

    return {
        hasAppMarkers: appMarkerPosition > JPEG_ID_SIZE,
        fileDataOffset: sof0DataOffset || sof2DataOffset,
        jfifDataOffset,
        tiffHeaderOffset,
        iptcDataOffset,
        xmpChunks,
        iccChunks,
        mpfDataOffset
    };
}

function isSOF0Marker(dataView, appMarkerPosition) {
    return (dataView.getUint16(appMarkerPosition) === SOF0_MARKER);
}

function isSOF2Marker(dataView, appMarkerPosition) {
    return (dataView.getUint16(appMarkerPosition) === SOF2_MARKER);
}

function isApp2ICCMarker(dataView, appMarkerPosition) {
    const markerIdLength = APP2_ICC_IDENTIFIER.length;

    // The ICC branch reads the two chunk bytes that follow the identifier, so a
    // segment without them must not be recognized here.
    return (dataView.getUint16(appMarkerPosition) === APP2_MARKER)
        && (appMarkerPosition + ICC_TOTAL_CHUNKS_OFFSET < dataView.byteLength)
        && (getStringFromDataView(dataView, appMarkerPosition + APP_ID_OFFSET, markerIdLength) === APP2_ICC_IDENTIFIER);
}

function isApp2MPFMarker(dataView, appMarkerPosition) {
    const markerIdLength = APP2_MPF_IDENTIFIER.length;

    return (dataView.getUint16(appMarkerPosition) === APP2_MARKER)
        && (getStringFromDataView(dataView, appMarkerPosition + APP_ID_OFFSET, markerIdLength) === APP2_MPF_IDENTIFIER);
}

function isApp0JfifMarker(dataView, appMarkerPosition) {
    const markerIdLength = APP0_JFIF_IDENTIFIER.length;

    return (dataView.getUint16(appMarkerPosition) === APP0_MARKER)
        && (getStringFromDataView(dataView, appMarkerPosition + APP_ID_OFFSET, markerIdLength) === APP0_JFIF_IDENTIFIER)
        && (dataView.getUint8(appMarkerPosition + APP_ID_OFFSET + markerIdLength) === 0x00);
}

function isApp1ExifMarker(dataView, appMarkerPosition) {
    const markerIdLength = APP1_EXIF_IDENTIFIER.length;

    return (dataView.getUint16(appMarkerPosition) === APP1_MARKER)
        && (getStringFromDataView(dataView, appMarkerPosition + APP_ID_OFFSET, markerIdLength) === APP1_EXIF_IDENTIFIER)
        && (dataView.getUint8(appMarkerPosition + APP_ID_OFFSET + markerIdLength) === 0x00);
}

function isApp1XmpMarker(dataView, appMarkerPosition) {
    return (dataView.getUint16(appMarkerPosition) === APP1_MARKER)
        && isXmpIdentifier(dataView, appMarkerPosition);
}

function isXmpIdentifier(dataView, appMarkerPosition) {
    const markerIdLength = APP1_XMP_IDENTIFIER.length;
    return getStringFromDataView(dataView, appMarkerPosition + APP_ID_OFFSET, markerIdLength) === APP1_XMP_IDENTIFIER;
}

function isApp1ExtendedXmpMarker(dataView, appMarkerPosition) {
    return (dataView.getUint16(appMarkerPosition) === APP1_MARKER)
        && isExtendedXmpIdentifier(dataView, appMarkerPosition);
}

function isExtendedXmpIdentifier(dataView, appMarkerPosition) {
    const markerIdLength = APP1_XMP_EXTENDED_IDENTIFIER.length;
    return getStringFromDataView(dataView, appMarkerPosition + APP_ID_OFFSET, markerIdLength) === APP1_XMP_EXTENDED_IDENTIFIER;
}

function getXmpChunkDetails(appMarkerPosition, fieldLength) {
    return {
        dataOffset: appMarkerPosition + XMP_DATA_OFFSET,
        length: fieldLength - (XMP_DATA_OFFSET - APP_MARKER_SIZE)
    };
}

function getExtendedXmpChunkDetails(appMarkerPosition, fieldLength) {
    return {
        dataOffset: appMarkerPosition + XMP_EXTENDED_DATA_OFFSET,
        length: fieldLength - (XMP_EXTENDED_DATA_OFFSET - APP_MARKER_SIZE)
    };
}

function isApp13PhotoshopMarker(dataView, appMarkerPosition) {
    const markerIdLength = APP13_IPTC_IDENTIFIER.length;
    const resourceIdentifierLength = APP13_RESOURCE_BLOCK_IDENTIFIER.length;
    const resourceIdentifierOffset = appMarkerPosition + APP_ID_OFFSET
        + markerIdLength + 1;

    // The null byte and the 8BIM identifier lie past the bytes the marker walk
    // guarantees, so a segment without them must not be recognized here.
    return (resourceIdentifierOffset + resourceIdentifierLength <= dataView.byteLength)
        && (dataView.getUint16(appMarkerPosition) === APP13_MARKER)
        && (getStringFromDataView(dataView, appMarkerPosition + APP_ID_OFFSET, markerIdLength) === APP13_IPTC_IDENTIFIER)
        && (dataView.getUint8(appMarkerPosition + APP_ID_OFFSET + markerIdLength) === 0x00)
        && (getStringFromDataView(dataView, resourceIdentifierOffset, resourceIdentifierLength) === APP13_RESOURCE_BLOCK_IDENTIFIER);
}

function isAppMarker(dataView, appMarkerPosition) {
    const appMarker = dataView.getUint16(appMarkerPosition);
    return ((appMarker >= APP0_MARKER) && (appMarker <= APP15_MARKER))
        || (appMarker === COMMENT_MARKER)
        || (appMarker === SOF0_MARKER)
        || (appMarker === SOF2_MARKER)
        || (appMarker === DHT_MARKER)
        || (appMarker === DQT_MARKER)
        || (appMarker === DRI_MARKER)
        || (appMarker === SOS_MARKER);
}

function isFillByte(dataView, appMarkerPosition) {
    return dataView.getUint16(appMarkerPosition) === FILL_BYTE;
}

function getExifMarkerScore(dataView, appMarkerPosition, fieldLength, tiffHeaderOffset) {
    const segmentEnd = appMarkerPosition + APP_MARKER_SIZE + fieldLength;
    const details = getExifTiffHeaderDetails(dataView, tiffHeaderOffset, segmentEnd);
    if (!details) {
        return 0;
    }

    const ifdEntriesScore = Number.isInteger(details.ifdEntries) ? details.ifdEntries : 0;

    return (details.isValid ? 1000000000 : 0)
        + (ifdEntriesScore * 1000000)
        + fieldLength;
}

function getExifTiffHeaderDetails(dataView, tiffHeaderOffset, segmentEnd) {
    try {
        if (tiffHeaderOffset + TIFF_HEADER_LENGTH > segmentEnd) {
            return undefined;
        }

        const byteOrderRaw = dataView.getUint16(
            tiffHeaderOffset + TIFF_BYTE_ORDER_OFFSET
        );
        const isLittleEndian = byteOrderRaw === ByteOrder.LITTLE_ENDIAN;
        if (!isLittleEndian && (byteOrderRaw !== ByteOrder.BIG_ENDIAN)) {
            return undefined;
        }

        const tiffId = dataView.getUint16(
            tiffHeaderOffset + TIFF_ID_OFFSET,
            isLittleEndian
        );
        if (tiffId !== TIFF_ID) {
            return undefined;
        }

        const ifdOffset = dataView.getUint32(
            tiffHeaderOffset + TIFF_IFD_OFFSET_OFFSET,
            isLittleEndian
        );
        const ifdEntryCountOffset = tiffHeaderOffset + ifdOffset;
        if (ifdEntryCountOffset + IFD_ENTRY_COUNT_LENGTH > segmentEnd) {
            return undefined;
        }

        const ifdEntries = dataView.getUint16(ifdEntryCountOffset, isLittleEndian);
        const ifdTotalLength = IFD_ENTRY_COUNT_LENGTH
            + (ifdEntries * IFD_ENTRY_LENGTH)
            + NEXT_IFD_POINTER_LENGTH;
        const hasFullIfd = (ifdEntryCountOffset + ifdTotalLength) <= segmentEnd;
        const isValid = hasFullIfd && (ifdEntries > 0);

        return {ifdEntries, isValid};
    } catch (error) {
        return undefined;
    }
}

function warnAboutMultipleExifSegments(exifSegmentCount) {
    /* eslint-disable no-console */
    if (typeof console === 'undefined' || typeof console.warn !== 'function') {
        return;
    }

    console.warn(
        `ExifReader: Found ${exifSegmentCount} Exif segments (APP1). `
        + 'Will pick the best candidate segment.'
    );
    /* eslint-enable no-console */
}
