# SPDX-License-Identifier: AGPL-3.0-only
__version__ = "0.1.0"
